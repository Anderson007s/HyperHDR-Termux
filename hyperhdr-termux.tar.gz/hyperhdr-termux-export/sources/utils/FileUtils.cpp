#ifndef PCH_ENABLED
	#include <QDir>
	#include <QFileInfo>
	#include <QDebug>
#endif

#include <utils/FileUtils.h>
#include <base/HyperHdrInstance.h>

namespace FileUtils {

	QString getBaseName(const QString& sourceFile)
	{
		QFileInfo fi(sourceFile);
		return fi.fileName();
	}

	bool readFile(const QString& path, QString& data, const LoggerName& log, bool ignError)
	{
		QFile file(path);
		if (!fileExists(path, log, ignError))
		{
			return false;
		}

		if (!file.open(QFile::ReadOnly | QFile::Text))
		{
			if (!ignError)
				resolveFileError(file, log);
			return false;
		}

		QTextStream in(&file);
		
		data = in.readAll();

		file.close();

		return true;
	}

	bool fileExists(const QString& path, const LoggerName& log, bool ignError)
	{
		if (!QFile::exists(path))
		{
			ErrorIf((!ignError), log, "File does not exist: {:s}", (path));
			return false;
		}
		return true;
	}

	bool writeFile(const QString& path, const QByteArray& data, const LoggerName& log)
	{
		QFile file(path);
		if (!file.open(QFile::WriteOnly | QFile::Truncate))
		{
			resolveFileError(file, log);
			return false;
		}

		if (file.write(data) == -1)
		{
			resolveFileError(file, log);
			return false;
		}

		file.close();
		return true;
	}

	void resolveFileError(const QFile& file, const LoggerName& log)
	{
		QFile::FileError error = file.error();
		QString fn = (file.fileName());
		switch (error)
		{
		case QFileDevice::NoError:
			Debug(log, "No error occurred while procesing file: {:s}", fn);
			break;
		case QFileDevice::ReadError:
			Error(log, "Can't read file: {:s}", fn);
			break;
		case QFileDevice::WriteError:
			Error(log, "Can't write file: {:s}", fn);
			break;
		case QFileDevice::FatalError:
			Error(log, "Fatal error while processing file: {:s}", fn);
			break;
		case QFileDevice::ResourceError:
			Error(log, "Resource Error while processing file: {:s}", fn);
			break;
		case QFileDevice::OpenError:
			Error(log, "Can't open file: {:s}", fn);
			break;
		case QFileDevice::AbortError:
			Error(log, "Abort Error while processing file: {:s}", fn);
			break;
		case QFileDevice::TimeOutError:
			Error(log, "Timeout Error while processing file: {:s}", fn);
			break;
		case QFileDevice::UnspecifiedError:
			Error(log, "Unspecified Error while processing file: {:s}", fn);
			break;
		case QFileDevice::RemoveError:
			Error(log, "Failed to remove file: {:s}", fn);
			break;
		case QFileDevice::RenameError:
			Error(log, "Failed to rename file: {:s}", fn);
			break;
		case QFileDevice::PositionError:
			Error(log, "Position Error while processing file: {:s}", fn);
			break;
		case QFileDevice::ResizeError:
			Error(log, "Resize Error while processing file: {:s}", fn);
			break;
		case QFileDevice::PermissionsError:
			Error(log, "Permission Error at file: {:s}", fn);
			break;
		case QFileDevice::CopyError:
			Error(log, "Error during file copy of file: {:s}", fn);
			break;
		default:
			break;
		}
	}
};
