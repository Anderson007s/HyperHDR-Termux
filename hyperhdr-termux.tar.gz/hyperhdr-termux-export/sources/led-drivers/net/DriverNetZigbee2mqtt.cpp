#include <led-drivers/net/DriverNetZigbee2mqtt.h>
#include <utils/GlobalSignals.h>
#include <utils/InternalClock.h>

namespace
{
	constexpr auto ZIGBEE_DISCOVERY_MESSAGE = "zigbee2mqtt/bridge/devices";
	constexpr int DEFAULT_TIME_MEASURE_MESSAGE = 25;
}

DriverNetZigbee2mqtt::DriverNetZigbee2mqtt(const QJsonObject& deviceConfig)
	: LedDevice(deviceConfig),
	_discoveryFinished(false),
	_timeLogger(0),
	_mqttId(mqttId++),
	_lastUpdate(0)
{
}

bool DriverNetZigbee2mqtt::init(QJsonObject deviceConfig)
{
	bool isInitOK = false;

	if (LedDevice::init(deviceConfig))
	{
		_zigInstance.transition = deviceConfig["transition"].toInt(0);
		_zigInstance.constantBrightness = deviceConfig["constantBrightness"].toInt(255);
		
		Debug(_log, "Transition (ms)       : {:s}", (_zigInstance.transition > 0) ? (QString::number(_zigInstance.transition)) : "disabled" );
		Debug(_log, "ConstantBrightness    : {:s}", (_zigInstance.constantBrightness > 0) ? (QString::number(_zigInstance.constantBrightness)) : "disabled");

		auto arr = deviceConfig["lamps"].toArray();

		for (const auto&& lamp : arr)
			if (lamp.isObject())
			{
				Zigbee2mqttLamp hl;
				auto lampObj = lamp.toObject();
				hl.name = lampObj["name"].toString();
				hl.colorModel = static_cast<Zigbee2mqttLamp::Mode>(lampObj["colorModel"].toInt(0));
				hl.currentBrightness = _zigInstance.constantBrightness;
				Debug(_log, "Configured lamp ({:s}) : {:s}", std::string_view((hl.colorModel == 0) ? "RGB" : "HSV"), (hl.name));
				_zigInstance.lamps.push_back(hl);
			}

		if (!arr.empty())
		{
			isInitOK = true;
		}
	}
	return isInitOK;
}


bool DriverNetZigbee2mqtt::powerOnOff(bool isOn)
{
	QJsonDocument doc;	
	QStringList lastWill;

	for (const auto& lamp : _zigInstance.lamps)
	{
		QString topic = QString("zigbee2mqtt/%1/set").arg(lamp.name);
		QJsonObject row;

		row["state"] = (isOn) ? "ON" : "OFF";
		
		doc.setObject(row);
		emit GlobalSignals::getInstance()->SignalMqttPublish(topic, doc.toJson(QJsonDocument::Compact));		

		if (isOn)
		{
			row["state"] = "OFF";
			doc.setObject(row);

			lastWill.push_back(topic);
			lastWill.push_back(doc.toJson(QJsonDocument::Compact));
		}
	}
	
	if (!_zigInstance.lamps.empty())
	{
		QString lastWillId = QString("DriverNetZigbee2mqtt:%1").arg(_mqttId);
		if (isOn)
		{
			emit GlobalSignals::getInstance()->SignalMqttLastWill(lastWillId, lastWill);
			connect(GlobalSignals::getInstance(), &GlobalSignals::SignalMqttReceived, this, &DriverNetZigbee2mqtt::handlerSignalMqttReceived, Qt::DirectConnection);
		}
		else
		{
			emit GlobalSignals::getInstance()->SignalMqttLastWill(lastWillId, QStringList());
			disconnect(GlobalSignals::getInstance(), &GlobalSignals::SignalMqttReceived, this, &DriverNetZigbee2mqtt::handlerSignalMqttReceived);
		}
	}

	_timeLogger = 0;
	_lastUpdate = InternalClock::now() - 9000;
	
	return true;
}

bool DriverNetZigbee2mqtt::powerOn()
{
	return powerOnOff(true);
}

bool DriverNetZigbee2mqtt::powerOff()
{
	return powerOnOff(false);
}

int DriverNetZigbee2mqtt::writeFiniteColors(const std::vector<ColorRgb>& ledValues)
{
	QJsonDocument doc;
	auto start = InternalClock::now();
	auto lastUpdate = _lastUpdate;

	auto rgb = ledValues.begin();
	for (auto& lamp : _zigInstance.lamps)
		if (rgb != ledValues.end())
		{
			QJsonObject row;
			auto& color = *(rgb++);
			int brightness = 0;
			
			QString topic = QString("zigbee2mqtt/%1/set").arg(lamp.name);

			if (_zigInstance.transition > 0)
			{
				row["transition"] = _zigInstance.transition / 1000.0;
			}

			if (lamp.colorModel == Zigbee2mqttLamp::Mode::RGB)
			{
				QJsonObject rgbColor; rgbColor["r"] = color.red; rgbColor["g"] = color.green; rgbColor["b"] = color.blue;
				row["color"] = rgbColor;
				brightness = std::min(std::max(static_cast<int>(std::roundl(0.2126 * color.red + 0.7152 * color.green + 0.0722 * color.blue)), 0), 255);
			}
			else
			{
				uint16_t h;
				float s, v;
				ColorRgb::rgb2hsl(color.red, color.green, color.blue, h, s, v);

				QJsonObject hs; hs["hue"] = h; hs["saturation"] = static_cast<int>(std::roundl(s * 100.0));
				row["color"] = hs;
				brightness = std::min(std::max(static_cast<int>(std::roundl(v * 255.0)), 0), 255);
			}

			if (_zigInstance.constantBrightness == 0)
			{				
				row["brightness"] = lamp.currentBrightness = brightness;				
			}
			else if (lamp.currentBrightness <= 0 && brightness > 0)
			{
				row["brightness"] = lamp.currentBrightness = _zigInstance.constantBrightness;
			}
			else if (lamp.currentBrightness > 0 && brightness == 0)
			{
				row["brightness"] = lamp.currentBrightness = 0;
			}
			else if (start - lastUpdate >= 10000)
			{
				_lastUpdate = start;
				row["brightness"] = lamp.currentBrightness;
			}

			doc.setObject(row);
			emit GlobalSignals::getInstance()->SignalMqttPublish(topic, doc.toJson(QJsonDocument::Compact));
			QThread::msleep(30);
		}
	
	if (_timeLogger >= 0 && _timeLogger < DEFAULT_TIME_MEASURE_MESSAGE)
	{
		Info(_log, "The communication took: {:d}ms ({:d}/{:d})", (int)(InternalClock::nowPrecise() - start), ++_timeLogger, DEFAULT_TIME_MEASURE_MESSAGE);
	}

	return 0;
}

void DriverNetZigbee2mqtt::handlerSignalMqttReceived(QString topic, QString payload)
{
	if (topic == ZIGBEE_DISCOVERY_MESSAGE && !_discoveryFinished)
	{
		_discoveryMessage = payload;
		_discoveryFinished = true;
	}
}

QJsonObject DriverNetZigbee2mqtt::discover(const QJsonObject& /*params*/)
{
	QJsonObject devicesDiscovered;
	QJsonArray deviceList;
	devicesDiscovered.insert("ledDeviceType", _activeDeviceType);

	_discoveryFinished = false;
	_discoveryMessage = "";

	connect(GlobalSignals::getInstance(), &GlobalSignals::SignalMqttReceived, this, &DriverNetZigbee2mqtt::handlerSignalMqttReceived, Qt::DirectConnection);
	emit GlobalSignals::getInstance()->SignalMqttSubscribe(false, ZIGBEE_DISCOVERY_MESSAGE);
	emit GlobalSignals::getInstance()->SignalMqttSubscribe(true, ZIGBEE_DISCOVERY_MESSAGE);

	for (int i = 0; i < 15 && !_discoveryFinished; i++)
	{
		QThread::msleep(100);
	}

	disconnect(GlobalSignals::getInstance(), &GlobalSignals::SignalMqttReceived, this, &DriverNetZigbee2mqtt::handlerSignalMqttReceived);
	emit GlobalSignals::getInstance()->SignalMqttSubscribe(false, ZIGBEE_DISCOVERY_MESSAGE);

	if (!_discoveryFinished)
	{
		Error(_log, "Could not find any Zigbee2mqtt devices. Check HyperHDR MQTT network / MQTT broker / Zigbee2mqtt configuration");
	}
	else
	{
		QJsonDocument doc = QJsonDocument::fromJson(_discoveryMessage.toUtf8());

		if (!doc.isNull())
		{
			if (doc.isArray())
			{
				const QJsonArray devices = doc.array();
				for (const auto& device : devices)
					if (device.isObject())
					{
						auto item = device.toObject();
						if (!item["friendly_name"].toString().isEmpty() &&
							item.contains("definition") && item["definition"].isObject())
						{
							auto defItem = item["definition"].toObject();
							if (defItem.contains("exposes") && defItem["exposes"].isArray())
							{
								const QJsonArray exposesArray = defItem["exposes"].toArray();
								for (const auto& exposesItem : exposesArray)
									if (exposesItem.isObject())
									{
										auto exposesObj = exposesItem.toObject();
										if (exposesObj.contains("type") && QString::compare(exposesObj["type"].toString(), "light", Qt::CaseInsensitive) == 0 &&
											exposesObj.contains("features") && exposesObj["features"].isArray())
										{
											const QJsonArray featuresArray = exposesObj["features"].toArray();
											for (const auto& featureItem : featuresArray)
												if (featureItem.isObject())
												{
													auto features = featureItem.toObject();
													if (features.contains("name"))
													{
														auto name = features["name"].toString();
														QString colorMode;

														if (QString::compare(name, "color_xy", Qt::CaseInsensitive) == 0)
														{
															colorMode = "RGB";
														}
														else if (QString::compare(name, "color_hs", Qt::CaseInsensitive) == 0)
														{
															colorMode = "HSV";
														}

														if (!colorMode.isEmpty())
														{
															QJsonObject newIp;
															newIp["value"] = colorMode;
															newIp["name"] = item["friendly_name"];
															deviceList.push_back(newIp);
															break;
														}
													}
												}
										}
									}
							}

						}
					}
			}
			else
			{
				Error(_log, "Document is not an array");
			}
		}
		else
		{
			Error(_log, "Document is not an JSON");
		}
	}

	devicesDiscovered.insert("devices", deviceList);
	Debug(_log, "devicesDiscovered: [{:s}]", QString(QJsonDocument(devicesDiscovered).toJson(QJsonDocument::Compact)).toUtf8().constData());

	return devicesDiscovered;
}

void DriverNetZigbee2mqtt::identify(const QJsonObject& params)
{
	if (params.contains("name") && params.contains("type"))
	{
		auto name = params["name"].toString();
		auto type = params["type"].toString();
		if (!name.isEmpty() && !type.isEmpty())
		{
			Debug(_log, "Testing lamp {:s} ({:s})", (name), (type));
			QString topic = QString("zigbee2mqtt/%1/set").arg(name);
			QJsonDocument doc;
			QJsonObject rowOn; rowOn["state"] = "ON";
			QJsonObject rowOff; rowOff["state"] = "OFF";
			QJsonObject colorRGB, rgb; colorRGB["brightness"] = 255; rgb["r"] = 255; rgb["g"] = 0; rgb["b"] = 0; colorRGB["color"] = rgb;
			QJsonObject colorHS, hs; colorHS["brightness"] = 255; hs["hue"] = 360; hs["saturation"] = 100; colorHS["color"] = hs;
			

			doc.setObject(rowOn);
			emit GlobalSignals::getInstance()->SignalMqttPublish(topic, doc.toJson(QJsonDocument::Compact));
			QThread::msleep(300);

			if (type == "RGB")
			{
				doc.setObject(colorRGB);
				emit GlobalSignals::getInstance()->SignalMqttPublish(topic, doc.toJson(QJsonDocument::Compact));
			}
			else
			{
				doc.setObject(colorHS);
				emit GlobalSignals::getInstance()->SignalMqttPublish(topic, doc.toJson(QJsonDocument::Compact));
			}
			QThread::msleep(700);

			doc.setObject(rowOff);
			emit GlobalSignals::getInstance()->SignalMqttPublish(topic, doc.toJson(QJsonDocument::Compact));
		}
	}
}


LedDevice* DriverNetZigbee2mqtt::construct(const QJsonObject& deviceConfig)
{
	return new DriverNetZigbee2mqtt(deviceConfig);
}

bool DriverNetZigbee2mqtt::isRegistered = hyperhdr::leds::REGISTER_LED_DEVICE("zigbee2mqtt", "leds_group_2_network", DriverNetZigbee2mqtt::construct);
